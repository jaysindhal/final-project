import { Express } from "express";
import { DataSource } from "typeorm";
import { Publisher } from "./publisher";

export default class PublishersApi {
  #dataSource: DataSource;
  #express: Express;

  constructor(dataSource: DataSource, express: Express) {
    this.#dataSource = dataSource;
    this.#express = express;

    this.#express.get("/publishers/:id", async (req, res) => {
      try {
        const publisher = await this.#dataSource.manager.findOneBy(Publisher, { publisher_id: parseInt(req.params.id) });
        if (!publisher) {
          return res.status(404).json({ error: "Publisher not found." });
        }
        return res.json(publisher);
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Publisher retrieval failed." });
      }
    });

    this.#express.post("/publishers", async (req, res) => {
      const { body } = req;
      const publisher = new Publisher();
      publisher.name = body.name;
      publisher.address = body.address;

      try {
        await this.#dataSource.manager.save(publisher);
        return res.status(201).json({ publisher_id: publisher.publisher_id });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Publisher creation failed in db." });
      }
    });

    this.#express.put("/publishers/:id", async (req, res) => {
      const { id } = req.params;
      const { body } = req;

      try {
        const publisherId = parseInt(id, 10);
        const publisher = await this.#dataSource.manager.findOneBy(Publisher, { publisher_id: publisherId });

        if (!publisher) {
          return res.status(404).json({ error: "Publisher not found." });
        }

        publisher.name = body.name || publisher.name;
        publisher.address = body.address || publisher.address;

        await this.#dataSource.manager.save(publisher);
        return res.json({ message: "Publisher updated successfully.", publisher });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Publisher update failed in db." });
      }
    });

    this.#express.delete("/publishers/:id", async (req, res) => {
      const { id } = req.params;

      try {
        const publisherId = parseInt(id, 10);
        const publisher = await this.#dataSource.manager.findOneBy(Publisher, { publisher_id: publisherId });

        if (!publisher) {
          return res.status(404).json({ error: "Publisher not found." });
        }

        await this.#dataSource.manager.remove(publisher);
        return res.json({ message: "Publisher deleted successfully." });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Publisher deletion failed in db." });
      }
    });
  }
}
