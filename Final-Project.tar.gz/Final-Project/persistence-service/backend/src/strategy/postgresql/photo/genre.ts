import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Genre {
  @PrimaryGeneratedColumn()
  genre_id: number;

  @Column({
    length: 255,
  })
  name: string;
}
