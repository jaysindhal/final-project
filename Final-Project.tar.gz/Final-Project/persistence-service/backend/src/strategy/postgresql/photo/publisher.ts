import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Publisher {
  @PrimaryGeneratedColumn()
  publisher_id: number;

  @Column({
    length: 255,
  })
  name: string;

  @Column("text")
  address: string;
}
