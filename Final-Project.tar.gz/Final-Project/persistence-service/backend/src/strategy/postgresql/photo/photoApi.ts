import { Express } from "express";
import { DataSource } from "typeorm";
import { Photo } from "./photo";

export default class PhotoApi {
  #dataSource: DataSource;
  #express: Express;

  constructor(dataSource: DataSource, express: Express) {
    this.#dataSource = dataSource;
    this.#express = express;

    this.#express.get("/photo/:id", async (req, res) => {
      try {
        const photo = await this.#dataSource.manager.findOneBy(Photo, { id: parseInt(req.params.id) });
        if (!photo) {
          return res.status(404).json({ error: "Photo not found." });
        }
        return res.json(photo);
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Photo retrieval failed." });
      }
    });

    this.#express.post("/photo", async (req, res) => {
      const { body } = req;
      console.log(body);

      const photo = new Photo();
      photo.name = body.name;
      photo.description = body.description;
      photo.filename = body.filename;
      photo.views = 0;
      photo.isPublished = true;

      try {
        await this.#dataSource.manager.save(photo);
        console.log(`Photo has been created with id: ${photo.id}`);
        return res.status(201).json({ id: photo.id });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Photo creation failed in db." });
      }
    });

    this.#express.put("/photo/:id", async (req, res) => {
      const { id } = req.params;
      const { body } = req;

      try {
        const photoId = parseInt(id, 10);
        const photo = await this.#dataSource.manager.findOneBy(Photo, { id: photoId });

        if (!photo) {
          return res.status(404).json({ error: "Photo not found." });
        }

        photo.name = body.name || photo.name;
        photo.description = body.description || photo.description;
        photo.filename = body.filename || photo.filename;
        photo.views = body.views !== undefined ? body.views : photo.views;
        photo.isPublished = body.isPublished !== undefined ? body.isPublished : photo.isPublished;

        await this.#dataSource.manager.save(photo);
        console.log(`Photo has been updated with id: ${photo.id}`);

        return res.json({ message: "Photo updated successfully.", photo });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Photo update failed in db." });
      }
    });

    this.#express.delete("/photo/:id", async (req, res) => {
      const { id } = req.params;

      try {
        const photoId = parseInt(id, 10);
        const photo = await this.#dataSource.manager.findOneBy(Photo, { id: photoId });

        if (!photo) {
          return res.status(404).json({ error: "Photo not found." });
        }

        await this.#dataSource.manager.remove(photo);
        console.log(`Photo has been deleted with id: ${photo.id}`);

        return res.json({ message: "Photo deleted successfully." });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Photo deletion failed in db." });
      }
    });
  }
}
