import { Express } from "express";
import { DataSource } from "typeorm";
import { Book } from "./book";

export default class BooksApi {
  #dataSource: DataSource;
  #express: Express;

  constructor(dataSource: DataSource, express: Express) {
    this.#dataSource = dataSource;
    this.#express = express;

    this.#express.get("/books/:id", async (req, res) => {
      try {
        const book = await this.#dataSource.manager.findOneBy(Book, { book_id: parseInt(req.params.id) });
        if (!book) {
          return res.status(404).json({ error: "Book not found." });
        }
        return res.json(book);
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Book retrieval failed." });
      }
    });

    this.#express.post("/books", async (req, res) => {
      const { body } = req;
      const book = new Book();
      book.title = body.title;
      book.genre_id = body.genre_id;
      book.price = body.price;
      book.format = body.format;
      book.author_id = body.author_id;
      book.publisher_id = body.publisher_id;
      book.published_date = body.published_date;
      book.stock_quantity = body.stock_quantity;

      try {
        await this.#dataSource.manager.save(book);
        return res.status(201).json({ book_id: book.book_id });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Book creation failed in db." });
      }
    });

    this.#express.put("/books/:id", async (req, res) => {
      const { id } = req.params;
      const { body } = req;

      try {
        const bookId = parseInt(id, 10);
        const book = await this.#dataSource.manager.findOneBy(Book, { book_id: bookId });

        if (!book) {
          return res.status(404).json({ error: "Book not found." });
        }

        book.title = body.title || book.title;
        book.genre_id = body.genre_id || book.genre_id;
        book.price = body.price || book.price;
        book.format = body.format || book.format;
        book.author_id = body.author_id || book.author_id;
        book.publisher_id = body.publisher_id || book.publisher_id;
        book.published_date = body.published_date || book.published_date;
        book.stock_quantity = body.stock_quantity || book.stock_quantity;

        await this.#dataSource.manager.save(book);
        return res.json({ message: "Book updated successfully.", book });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Book update failed in db." });
      }
    });

    this.#express.delete("/books/:id", async (req, res) => {
      const { id } = req.params;

      try {
        const bookId = parseInt(id, 10);
        const book = await this.#dataSource.manager.findOneBy(Book, { book_id: bookId });

        if (!book) {
          return res.status(404).json({ error: "Book not found." });
        }

        await this.#dataSource.manager.remove(book);
        return res.json({ message: "Book deleted successfully." });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Book deletion failed in db." });
      }
    });
  }
}
