import { Express } from "express";
import { DataSource } from "typeorm";
import { Review } from "./review"; // Adjust the import path if necessary

export default class ReviewApi {
  #dataSource: DataSource;
  #express: Express;

  constructor(dataSource: DataSource, express: Express) {
    this.#dataSource = dataSource;
    this.#express = express;

    this.#express.get("/review/:id", async (req, res) => {
      try {
        const review = await this.#dataSource.manager.findOneBy(Review, { review_id: parseInt(req.params.id) });
        if (!review) {
          return res.status(404).json({ error: "Review not found." });
        }
        return res.json(review);
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Review retrieval failed." });
      }
    });

    this.#express.post("/review", async (req, res) => {
      const { body } = req;
      console.log(body);

      const review = new Review();
      review.book_id = body.book_id;
      review.customer_id = body.customer_id;
      review.rating = body.rating;
      review.review_text = body.review_text;
      review.review_date = new Date(); // Or use body.review_date if provided

      try {
        await this.#dataSource.manager.save(review);
        console.log(`Review has been created with id: ${review.review_id}`);
        return res.status(201).json({ review_id: review.review_id });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Review creation failed in db." });
      }
    });

    this.#express.put("/review/:id", async (req, res) => {
      const { id } = req.params;
      const { body } = req;

      try {
        const reviewId = parseInt(id, 10);
        const review = await this.#dataSource.manager.findOneBy(Review, { review_id: reviewId });

        if (!review) {
          return res.status(404).json({ error: "Review not found." });
        }

        review.book_id = body.book_id || review.book_id;
        review.customer_id = body.customer_id || review.customer_id;
        review.rating = body.rating !== undefined ? body.rating : review.rating;
        review.review_text = body.review_text || review.review_text;
        review.review_date = body.review_date ? new Date(body.review_date) : review.review_date;

        await this.#dataSource.manager.save(review);
        console.log(`Review has been updated with id: ${review.review_id}`);

        return res.json({ message: "Review updated successfully.", review });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Review update failed in db." });
      }
    });

    this.#express.delete("/review/:id", async (req, res) => {
      const { id } = req.params;

      try {
        const reviewId = parseInt(id, 10);
        const review = await this.#dataSource.manager.findOneBy(Review, { review_id: reviewId });

        if (!review) {
          return res.status(404).json({ error: "Review not found." });
        }

        await this.#dataSource.manager.remove(review);
        console.log(`Review has been deleted with id: ${review.review_id}`);

        return res.json({ message: "Review deleted successfully." });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Review deletion failed in db." });
      }
    });
  }
}
