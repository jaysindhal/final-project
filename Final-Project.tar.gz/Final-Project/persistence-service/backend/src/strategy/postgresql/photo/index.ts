// src/strategy/postgresql/photo/index.ts

// Import API classes
import PhotoApi from "./photoApi";
import ReviewApi from "./reviewApi";
import AuthorsApi from "./authorsApi";
import GenresApi from "./GenresApi";
import PublishersApi from "./publishersApi";

// Import entities
import { Photo } from "./photo";
import { Review } from "./review";
import { Author } from "./authors";
import { Genre } from "./genre";
import { Publisher } from "./publisher";
import { Book } from "./book";

// Export API classes
export { PhotoApi, ReviewApi, AuthorsApi, GenresApi, PublishersApi };

// Export entities
export { Photo, Review, Author, Genre, Publisher, Book };
