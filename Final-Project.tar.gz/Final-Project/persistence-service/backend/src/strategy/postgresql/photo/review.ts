import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Review {
  @PrimaryGeneratedColumn()
  review_id: number;

  @Column()
  book_id: number;

  @Column()
  customer_id: number;

  @Column("int")
  rating: number;

  @Column("text")
  review_text: string;

  @Column("date")
  review_date: Date;
}
