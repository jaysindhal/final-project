import { Express } from "express";
import { DataSource } from "typeorm";
import { Genre } from "./genre";

export default class GenresApi {
  #dataSource: DataSource;
  #express: Express;

  constructor(dataSource: DataSource, express: Express) {
    this.#dataSource = dataSource;
    this.#express = express;

    this.#express.get("/genres/:id", async (req, res) => {
      try {
        const genre = await this.#dataSource.manager.findOneBy(Genre, { genre_id: parseInt(req.params.id) });
        if (!genre) {
          return res.status(404).json({ error: "Genre not found." });
        }
        return res.json(genre);
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Genre retrieval failed." });
      }
    });

    this.#express.post("/genres", async (req, res) => {
      const { body } = req;
      const genre = new Genre();
      genre.name = body.name;

      try {
        await this.#dataSource.manager.save(genre);
        return res.status(201).json({ genre_id: genre.genre_id });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Genre creation failed in db." });
      }
    });

    this.#express.put("/genres/:id", async (req, res) => {
      const { id } = req.params;
      const { body } = req;

      try {
        const genreId = parseInt(id, 10);
        const genre = await this.#dataSource.manager.findOneBy(Genre, { genre_id: genreId });

        if (!genre) {
          return res.status(404).json({ error: "Genre not found." });
        }

        genre.name = body.name || genre.name;

        await this.#dataSource.manager.save(genre);
        return res.json({ message: "Genre updated successfully.", genre });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Genre update failed in db." });
      }
    });

    this.#express.delete("/genres/:id", async (req, res) => {
      const { id } = req.params;

      try {
        const genreId = parseInt(id, 10);
        const genre = await this.#dataSource.manager.findOneBy(Genre, { genre_id: genreId });

        if (!genre) {
          return res.status(404).json({ error: "Genre not found." });
        }

        await this.#dataSource.manager.remove(genre);
        return res.json({ message: "Genre deleted successfully." });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Genre deletion failed in db." });
      }
    });
  }
}
