import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Book {
  @PrimaryGeneratedColumn()
  book_id: number;

  @Column({
    length: 255,
  })
  title: string;

  @Column("int")
  genre_id: number;

  @Column("decimal", { precision: 10, scale: 2 })
  price: number;

  @Column({
    length: 20,
  })
  format: string;

  @Column("int")
  author_id: number;

  @Column("int")
  publisher_id: number;

  @Column("date")
  published_date: string;

  @Column("int")
  stock_quantity: number;
}
