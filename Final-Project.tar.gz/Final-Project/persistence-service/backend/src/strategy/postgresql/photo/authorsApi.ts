import { Express } from "express";
import { DataSource } from "typeorm";
import { Author } from "./author";

export default class AuthorsApi {
  #dataSource: DataSource;
  #express: Express;

  constructor(dataSource: DataSource, express: Express) {
    this.#dataSource = dataSource;
    this.#express = express;

    this.#express.get("/authors/:id", async (req, res) => {
      try {
        const author = await this.#dataSource.manager.findOneBy(Author, { author_id: parseInt(req.params.id) });
        if (!author) {
          return res.status(404).json({ error: "Author not found." });
        }
        return res.json(author);
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Author retrieval failed." });
      }
    });

    this.#express.post("/authors", async (req, res) => {
      const { body } = req;
      const author = new Author();
      author.name = body.name;
      author.bio = body.bio;

      try {
        await this.#dataSource.manager.save(author);
        return res.status(201).json({ author_id: author.author_id });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Author creation failed in db." });
      }
    });

    this.#express.put("/authors/:id", async (req, res) => {
      const { id } = req.params;
      const { body } = req;

      try {
        const authorId = parseInt(id, 10);
        const author = await this.#dataSource.manager.findOneBy(Author, { author_id: authorId });

        if (!author) {
          return res.status(404).json({ error: "Author not found." });
        }

        author.name = body.name || author.name;
        author.bio = body.bio || author.bio;

        await this.#dataSource.manager.save(author);
        return res.json({ message: "Author updated successfully.", author });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Author update failed in db." });
      }
    });

    this.#express.delete("/authors/:id", async (req, res) => {
      const { id } = req.params;

      try {
        const authorId = parseInt(id, 10);
        const author = await this.#dataSource.manager.findOneBy(Author, { author_id: authorId });

        if (!author) {
          return res.status(404).json({ error: "Author not found." });
        }

        await this.#dataSource.manager.remove(author);
        return res.json({ message: "Author deleted successfully." });
      } catch (err) {
        console.error(err);
        return res.status(503).json({ error: "Author deletion failed in db." });
      }
    });
  }
}
