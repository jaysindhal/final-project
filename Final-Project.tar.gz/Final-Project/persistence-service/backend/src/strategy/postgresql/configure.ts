import { DataSource } from "typeorm";
import { Photo } from "./photo/photo";

export const postgresDataSource = new DataSource({
  type: "postgres",
  host: process.env.DB_HOST,
  port: 5432,
  username: 'postgres',
  password: 'postgres',
  database: 'postgres',
  entities: [Photo],
  synchronize: true,
  logging: false,
});
