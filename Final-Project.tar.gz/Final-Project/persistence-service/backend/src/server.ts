import cors from "cors";
import express, { json } from "express";
import postgresDataSource from "./strategy/postgresql";
import { PhotoApi, ReviewApi } from "./strategy/postgresql/photo";

(async () => {
  const app = express();
  app.use(cors());
  app.use(json());

  const datasource = await postgresDataSource.initialize();

  // Initialize API classes with the datasource and express app
  new PhotoApi(datasource, app);
  new ReviewApi(datasource, app);

  app.get("/", (_, res) => {
    return res.send("hello world");
  });

  app.listen(8000, () => {
    console.log(`Express server started on port 8000`);
  });
})().catch((err) => console.log(err));
